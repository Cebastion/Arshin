		<div class="content__cities">
			<div class="cities__title">
				<h2>Другие города</h2>
			</div>
			<ul class="cities__block">
			    
				<li class="cities__name" data-lat="59.9390" data-lng="30.3158"><a href="./our_office.php">Москва</a></li>
				<li class="cities__name" data-lat="59.9390" data-lng="30.3158"><a href="./Petersburg.php">Санкт Петербург</a></li>
				<li class="cities__name" data-lat="55.8095" data-lng="37.9584"><a href="./Balashikha.php">Балашиха</a></li>
				<li class="cities__name" data-lat="54.6293" data-lng="39.7364"><a href="./Ryazan.php">Рязань</a></li>
				<li class="cities__name" data-lat="57.6264" data-lng="39.8938"><a href="./Yaroslavl.php">Ярославль</a></li>
				<li class="cities__name" data-lat="54.1930" data-lng="37.6175"><a href="./Tula.php">Тула</a></li>
				<li class="cities__name" data-lat="45.0402" data-lng="38.9760"><a href="./Krasnodar.php">Краснодар</a></li>
			</ul>
		</div>