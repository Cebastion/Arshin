const clearButtons = document.querySelectorAll(".button")
const homeButton = document.querySelector('.thanks__button')

homeButton.addEventListener("click", () => {
    window.location.href = "./index.php"
})