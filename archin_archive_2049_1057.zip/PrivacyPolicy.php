<?php
$Description = ''; //ТУТ ПИШИТЕ ОПИСАНИЕ
$KeyWords = ''; //ТУТ ПИШИТЕ КЛЮЧЕВЫЕ СЛОВА
$Robots = ''; // УКАЗАТЬ, КАКИЕ ДЕЙСТВИЯ РОБОТЫ ДОЛЖНЫ ПРЕДПРИНИМАТЬ В ОТНОШЕНИИ ВАШЕЙ СТРАНИЦЫ
include("./components/header.php")
?>
<main class="content">
  <div class="content__container">
    <div class="content__privacy-policy">
      <span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam ducimus ipsum magnam animi ex magni sit est mollitia, cum quos officiis commodi accusantium rem blanditiis odit doloribus dolor asperiores? Animi.
      Unde illo tenetur enim aut deserunt cumque est ab nihil accusantium, repellat dignissimos labore? Ex neque, quos accusamus tempore cum dolores vel placeat fugiat accusantium, autem sit ea voluptate laudantium!
      Nobis odio et ullam molestiae iusto maiores amet, consectetur similique officia omnis rerum delectus provident corrupti quidem explicabo? Voluptates excepturi quas alias nam beatae placeat voluptas numquam, nisi architecto cum.
      Dolorem voluptates quam consectetur facilis, iste, explicabo quisquam nostrum qui delectus quos vel, eos sunt quo? Excepturi, ex veniam? Ullam cum et ut laborum labore pariatur! Rem quis laudantium quidem!
      Sunt animi necessitatibus porro consequatur placeat odio, dignissimos sed facilis consectetur nulla maxime optio nam et? Mollitia ducimus sapiente accusantium quas, et, repellendus nisi commodi optio, amet blanditiis nesciunt sequi.
      Atque cumque reprehenderit quod autem. Quasi iusto natus distinctio? Excepturi voluptatum nemo cum ullam atque eveniet nisi tenetur iste officiis perspiciatis et, quibusdam veniam tempora ab dolore illo rem. Consectetur?
      Amet inventore blanditiis ea et sapiente similique a, unde explicabo fugiat accusantium illum vero! Voluptates, facere inventore. Similique repellat itaque facere explicabo voluptatem, distinctio quas deleniti tenetur ipsum temporibus dignissimos!
      Voluptatem mollitia, obcaecati dolore pariatur sed nemo voluptatibus. Distinctio quia nostrum porro eaque itaque libero. Qui eveniet, voluptatum eum nam ratione dolor velit odio ducimus dicta excepturi nesciunt incidunt officia.
      Enim quasi officiis, modi ea maxime quam iusto amet commodi aperiam, odio consectetur voluptas accusantium sit alias totam dolorem minus provident dicta ab at voluptatem rerum ad minima cupiditate! Quo.
      Recusandae adipisci itaque a fugiat consequuntur illo ut totam vel quidem sequi dolor provident repellendus possimus voluptatum corporis ratione, omnis obcaecati inventore neque magni error? Voluptate aliquid sunt labore inventore.</span>
    </div>
  </div>
</main>
<?php include("./components/footer.php") ?>