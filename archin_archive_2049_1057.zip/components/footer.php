<footer class="footer">
  <div class="footer__container">
    <div class="footer__row">
      <div class="footer__column">
        <div class="footer__logo">
          <div class="logo__img">
            <a href="./">
              <img src='./image/logo.webp' alt='logo' />
            </a>
          </div>
          <div class="logo__text">
            <span>Официальная метрологическая служба России. Москва и область.</span>
          </div>
        </div>
        <div class="footer__contact">
          <div class="contact__phone">
            <span>8 (999) 333-22-11</span>
          </div>
          <div class="contact__mail">
            <span>info@mail.ru</span>
          </div>
          <div class="footer__location">
            <span>1-я Тверская-Ямская улица, 29с1</span>
          </div>
          <div class="footer__time">
            <span>Ежедневно с 9:00 до 21:00</span>
          </div>
        </div>
        <div class="footer__rights">
          <span>Все права защищены 2020-2023</span>
        </div>
      </div>
      <div class="footer__column">
        <ul class="footer__menu">
          <li><a href="./">Главная</a></li>
          <li><a href="./service.php">Услуги</a></li>
          <li><a href="#">Стоимость</a></li>
          <li><a href="#">Юр. лицам</a></li>
          <li><a href="./our_office.php">Наши офисы</a></li>
        </ul>
      </div>
      <div class="footer__column">
        <ul class="footer__menu">
          <li><a href="#">О компании</a></li>
          <li><a href="./license.php">Лицензии</a></li>
          <li><a href="./contact.php">Контакты</a></li>
          <li><a href="#">Отзывы</a></li>
          <li><a href="#">Наши клиенты</a></li>
          <li><a href="#">Вакансии</a></li>
          <li><a href="#">Полезная информация</a></li>
        </ul>
      </div>
    </div>
  </div>
</footer>
</div>
</body>

</html>